
package engtelecom.poo;

import java.io.IOException;
import java.nio.file.FileSystem;
import java.nio.file.FileSystems;
import java.nio.file.Path;

import com.google.zxing.BarcodeFormat;
import com.google.zxing.WriterException;
import com.google.zxing.client.j2se.MatrixToImageWriter;
import com.google.zxing.common.BitMatrix;
import com.google.zxing.qrcode.QRCodeWriter;
import com.google.zxing.qrcode.encoder.QRCode;

import barcode.CodigoDeBarra;

public class App {

    public static void main(String[] args) throws IOException, WriterException {
       
    // CodigoDeBarra.gerarCodigoDeBarra("111.222.333-44", "cpf.png");

    String valor = "Beatriz Abreu";

    QRCodeWriter qrCodeWriter = new QRCodeWriter();

    BitMatrix bitMatrix = qrCodeWriter.encode(valor, BarcodeFormat.QR_CODE, 600, 600);

    Path caminho = FileSystems.getDefault().getPath("qrcorde.png");
    MatrixToImageWriter.writeToPath(bitMatrix,"PNG", caminho);


    }
}
